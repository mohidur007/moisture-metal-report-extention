// ---- Runs inside the Qarma page (all frames). Must be self-contained. ----
function extractor() {
  const text = document.body ? document.body.innerText : '';
  const grab = (re) => { const m = text.match(re); return m ? m[1].trim() : ''; };
  const LABEL = /^(order\s*no|order\s*number|item\s*no|item\s*number|item\s*name|order\s*qty|sample\s*qty|inspector|supplier|inspection|location|duration|quality|packing|checklist|sampling|production)/i;
  const PO_RE = /\bGMS[A-Z]{0,4}\d{6,8}\b/;
  const tokens = text.split(/[\t\n]+/).map((s) => s.trim()).filter(Boolean);
  const pos = Array.from(new Set(text.match(/\bGMS[A-Z]{0,4}\d{6,8}\b/g) || []));

  let orderNo = grab(/Order\s*No\.?[\s:]+([A-Za-z0-9+\-]+)/i);
  if (!PO_RE.test(orderNo)) orderNo = '';
  let itemNo = grab(/Item\s*no\.?[\s:]+(\d{6,9})\b/i);
  let itemName = grab(/Item\s*name[\s:]+([^\n\t]+)/i);
  if (!itemName || LABEL.test(itemName)) itemName = '';

  // Table layout (combined inspection / several orders): header cells, then one row per order
  const items = [];
  const h = tokens.findIndex((t, i) => /^order\s*(no\.?|number)$/i.test(t) && tokens.slice(i, i + 8).some((x) => /^item\s*name$/i.test(x)));
  if (h >= 0) {
    for (let i = h + 1; i < tokens.length; i++) {
      const pm = tokens[i].length < 30 && tokens[i].match(/(GMS[A-Z]{0,4}\d{6,8})$/);
      if (!pm) continue;
      for (let k = i + 1; k <= i + 4 && k < tokens.length; k++) {
        if (/^\d{6,9}$/.test(tokens[k])) {
          const nm = tokens[k + 1];
          if (!items.some((x) => x.po === pm[1])) items.push({ po: pm[1], itemNo: tokens[k], itemName: nm && !/^[\d\s\/.,]+$/.test(nm) && !LABEL.test(nm) ? nm : '' });
          break;
        }
      }
    }
  }
  if (!items.length && (itemNo || itemName)) items.push({ po: orderNo, itemNo, itemName });
  if (items.length) {
    const uniq = (a) => Array.from(new Set(a.filter(Boolean)));
    if (!itemNo) itemNo = uniq(items.map((x) => x.itemNo)).join(' / ');
    if (!itemName) itemName = uniq(items.map((x) => x.itemName)).join(' / ');
  }
  // Page title: "10323756 · STYLE NAME"
  if (!itemNo || !itemName) {
    const m = text.match(/^\s*(\d{6,9})\s*[·•]\s*([^\n]+)/m);
    if (m) { if (!itemNo) itemNo = m[1]; if (!itemName) itemName = m[2].trim(); }
  }

  let composition = grab(/Composition\s*:\s*([^\n]+)/i);
  if (!composition) {
    const m = text.match(/(\d{1,3}\s*%\s*[A-Za-z][A-Za-z \-]*(?:,\s*\d{1,3}\s*%\s*[A-Za-z][A-Za-z \-]*)*)/);
    if (m) composition = m[1].trim();
  }

  let inspector = grab(/^Inspector(?![’'s])[ \t:]*\n?[ \t]*([^\n\t]+)/im);
  if (inspector.includes(' - ')) inspector = inspector.split(' - ').pop().trim();

  // Brand (shown as BUYER on the metal report)
  let brand = grab(/\bBrand(?:\s*name)?\s*[:\t]\s*([^\n\t]+)/i);
  if (!brand || LABEL.test(brand)) {
    brand = '';
    const bi = tokens.findIndex((t) => /^brand(\s*name)?$/i.test(t));
    if (bi >= 0 && tokens[bi + 1] && !LABEL.test(tokens[bi + 1]) && tokens[bi + 1].length < 40) brand = tokens[bi + 1];
  }

  return { orderNo, itemNo, itemName, composition, inspector, pos, brand, items };
}

// ---- Shows the form as a modal on the page. Refreshing the tab removes it. ----
function showOverlay(url) {
  const old = document.getElementById('mr-overlay');
  if (old) old.remove();
  const wrap = document.createElement('div');
  wrap.id = 'mr-overlay';
  wrap.style.cssText = 'position:fixed;inset:0;z-index:2147483647;display:flex;align-items:center;justify-content:center;background:rgba(120,130,150,.35);backdrop-filter:blur(7px);-webkit-backdrop-filter:blur(7px);';
  const box = document.createElement('div');
  box.style.cssText = 'position:relative;width:min(1240px,96vw);height:min(94vh,900px);border-radius:26px;overflow:hidden;background:#e6ebf2;box-shadow:0 30px 80px rgba(60,70,95,.45);';
  const frame = document.createElement('iframe');
  frame.src = url;
  frame.style.cssText = 'width:100%;height:100%;border:0;display:block;';
  const close = document.createElement('button');
  close.textContent = '✕';
  close.title = 'Close';
  close.style.cssText = 'position:absolute;top:14px;right:16px;z-index:2;width:34px;height:34px;border:0;border-radius:50%;background:#e6ebf2;color:#475569;font:14px Arial;cursor:pointer;box-shadow:4px 4px 9px #c3c9d4,-4px -4px 9px #fff;';
  close.onclick = () => wrap.remove();
  box.append(frame, close);
  wrap.append(box);
  document.documentElement.appendChild(wrap);
}

const msg = (s) => (document.getElementById('msg').textContent = s);

async function openForm(page) {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const res = await chrome.scripting.executeScript({ target: { tabId: tab.id, allFrames: true }, func: extractor });
    const data = { orderNo: '', itemNo: '', itemName: '', composition: '', inspector: '', brand: '', pos: [], items: [] };
    for (const r of res) {
      const v = r.result || {};
      for (const k of ['orderNo', 'itemNo', 'itemName', 'composition', 'inspector', 'brand']) if (!data[k] && v[k]) data[k] = v[k];
      for (const p of v.pos || []) if (!data.pos.includes(p)) data.pos.push(p);
      for (const it of v.items || []) if (!data.items.some((x) => x.po === it.po)) data.items.push(it);
    }
    await chrome.storage.local.set({ pageData: data });
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: showOverlay, args: [chrome.runtime.getURL(page)] });
    window.close();
  } catch (e) {
    msg('Cannot open on this page. Open the Qarma inspection page first.');
  }
}
document.getElementById('moisture').onclick = () => openForm('report.html');
document.getElementById('metal').onclick = () => openForm('metal.html');
