// Futuristic start-up sequence shown for about a second when a form opens (skipped when motion is reduced).
window.runBoot = function (found, total, done) {
  const el = document.getElementById('boot');
  const reduce = !!(window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches);
  if (!el || reduce) { if (el) el.remove(); done(); return; }
  const box = el.querySelector('.bl');
  const lines = ['> LINK ESTABLISHED', '> PARSING PAGE DATA', `> FIELDS LOCATED   ${found} / ${total}`, '> SYSTEM ONLINE'];
  let i = 0;
  const next = () => {
    if (i < lines.length) { const d = document.createElement('div'); d.textContent = lines[i++]; box.appendChild(d); setTimeout(next, 210); }
    else setTimeout(() => { el.classList.add('off'); setTimeout(() => el.remove(), 480); done(); }, 220);
  };
  next();
};
