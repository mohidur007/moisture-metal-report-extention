(async function () {
  const $ = (id) => document.getElementById(id);
  const pd = (await chrome.storage.local.get(['pageData'])).pageData || {};
  const MAXR = 22;
  const NOTES = [
    '(*)Total quantity of easy body and children orders should pass tha needle detector machine.',
    '(*)If any sample fails ,find tha metal detector part keep it in a sepaeate report.',
    '(*)If metal part is not found , put failling garments a side and mark sure it is destroyed.',
    '(*)Each garments should pass the needle detector one as final check just before packing.',
    '(*)Make sure garments dones not return back into productiuon unit after needle detection is made.',
    '(*)Metal detector machine should be calibrated at least 3 times a day.'
  ];
  const COLS = [114, 138, 93, 161, 445, 138, 110, 111, 121];
  const KEYS = ['date', 'time', 'cal', 'buyer', 'style', 'order', 'chk', 'fail', 'sign'];
  const pad = (n) => String(n).padStart(2, '0');
  const d = new Date();
  const today = `${pad(d.getDate())}.${pad(d.getMonth() + 1)}.${d.getFullYear()}`;

  // ---- values from the page (only the first order)
  const first = (pd.items && pd.items[0]) || null;
  $('i-order').value = (first && first.po) || pd.orderNo || (pd.pos && pd.pos[0]) || '';
  $('i-sname').value = (first && first.itemName) || (pd.itemName || '').split(' / ')[0] || '';
  $('i-brand').value = pd.brand || '';
  $('p-sub').textContent = [$('i-order').value, $('i-sname').value].filter(Boolean).join(' · ') || 'Fill the details, then print or download Excel';

  const rows = Array.from({ length: MAXR }, () => Object.fromEntries(KEYS.map((k) => [k, ''])));
  let active = 1;
  const defaults = () => ({ date: today, time: '', cal: 'YES', buyer: $('i-brand').value.trim(), style: $('i-sname').value.trim(), order: $('i-order').value.trim(), chk: $('i-chk').value.trim(), fail: 'NO', sign: '' });

  // ---- build the sheet (same grid as the Excel file)
  const lvl = () => 'Level :  ' + $('i-level').value + ' ';
  const flr = () => 'Floor : ' + $('i-floor').value;
  const h = (pt, cells) => `<tr style="height:${pt}pt">${cells}</tr>`;
  const c = (txt, o = {}) => `<td${o.cs ? ` colspan="${o.cs}"` : ''}${o.id ? ` id="${o.id}"` : ''} class="${o.cls || ''}" style="${o.st || ''}">${txt}</td>`;
  function build() {
    let t = '<colgroup>' + COLS.map((w) => `<col style="width:${w}px">`).join('') + '</colgroup><tbody>';
    t += h(15, c('', { cs: 9 }));
    t += h(20.25, c('', { cs: 4 }) + c('GMS COMPOSITE KNITTING .IND .LTD', { cs: 5, st: 'font-size:20pt;font-weight:bold' }));
    t += h(20.25, c('', { cs: 4 }) + c('          SARDAGONJ,KASHIMPUR,GAZIPUR', { cs: 5, st: 'font-size:16pt;font-weight:bold;vertical-align:middle' }));
    t += h(18.75, c('', { cs: 4 }) + c('                                       METAL DETECTOR REPORT', { cs: 5, st: 'font-weight:bold;vertical-align:top' }));
    [18.75, 16.5, 17.25, 17.25, 16.5].forEach((ht, i) => { t += h(ht, c(NOTES[i], { cs: 5 }) + c('', { cs: 4 })); });
    t += h(16.5, c(NOTES[5], { cs: 5 }) + c(lvl(), { cs: 2, id: 'f-level', st: 'font-size:14pt;text-align:center' }) + c(flr(), { cs: 2, id: 'f-floor', st: 'font-size:14pt' }));
    t += h(11.25, c('', { cs: 9 }));
    const hd = [['DATE', 'font-size:14pt'], ['TIME', 'font-size:14pt'], ['CALIBRATED', ''], ['BUYER', 'font-size:14pt'], ['STYLE NAME', 'font-size:14pt'], ['ORDER NO', 'font-family:Arial,sans-serif'], ['NO OF GARMENTS CHECKED', 'white-space:normal;vertical-align:top'], ['NO OF GMT FAILING', 'white-space:normal'], ['SIGN', 'font-size:14pt']];
    t += h(31.5, hd.map(([x, st]) => c(x, { cls: 'g', st })).join(''));
    for (let i = 0; i < MAXR; i++) {
      t += `<tr style="height:20.25pt" data-i="${i}">` + KEYS.map((k, j) => `<td class="g ed${j === 1 || j === 8 ? '' : ' ar'}" contenteditable="true" data-k="${k}"></td>`).join('') + '</tr>';
    }
    t += h(20.25, c('', { cs: 5, cls: 'g' }) + c('TOTAL', { cls: 'g', st: 'font-size:12pt;font-weight:bold' }) + c('', { cls: 'g ar', id: 'f-total' }) + c('', { cls: 'g' }) + c('', { cls: 'g' }));
    t += h(20.25, c('', { cs: 9 })) + h(15, c('', { cs: 9 })) + h(20.25, c('', { cs: 9 }));
    t += h(20.25, c('') + c('PREPARED BY', { cls: 'tb', st: 'font-size:12pt;font-weight:bold;text-align:center;vertical-align:middle' }) + c('') + c('') + c('FINISHING MANAGER', { cls: 'tb', st: 'font-size:12pt;font-weight:bold;text-align:center;vertical-align:middle' }) + c('') + c('') + c('           APPROVED BY', { cs: 2, cls: 'tb', st: 'font-size:12pt;font-weight:bold;vertical-align:top' }));
    $('mt').innerHTML = t + '</tbody>';
  }

  function render() {
    document.querySelectorAll('#mt tr[data-i]').forEach((tr) => {
      const r = rows[+tr.dataset.i];
      tr.querySelectorAll('td[data-k]').forEach((td) => { td.textContent = r[td.dataset.k]; });
    });
    $('f-level').textContent = lvl(); $('f-floor').textContent = flr();
    total();
  }
  function total() {
    const v = rows.map((r) => parseFloat(r.chk)).filter((x) => !isNaN(x));
    $('f-total').textContent = v.length ? String(v.reduce((a, b) => a + b, 0)) : '';
  }
  function setActive(n) {
    n = Math.min(MAXR, Math.max(1, n || 1));
    const dflt = defaults();
    rows.forEach((r, i) => {
      if (i < n) { if (i >= active || !KEYS.some((k) => r[k])) Object.assign(r, dflt); }
      else KEYS.forEach((k) => (r[k] = ''));
    });
    active = n; render();
  }
  // panel fields update the matching column of every filled row
  const bind = (id, key) => ($(id).oninput = () => { for (let i = 0; i < active; i++) rows[i][key] = $(id).value.trim(); render(); });
  bind('i-brand', 'buyer'); bind('i-sname', 'style'); bind('i-order', 'order'); bind('i-chk', 'chk');
  $('i-level').onchange = render;
  $('i-floor').oninput = () => {   // floor name is always written in capital letters
    const el = $('i-floor'), pos = el.selectionStart;
    el.value = el.value.toUpperCase();
    el.setSelectionRange(pos, pos);
    render();
  };
  $('i-rows').oninput = () => { const n = parseInt($('i-rows').value); if (!isNaN(n)) setActive(n); };

  $('mt').addEventListener('input', (e) => {
    const td = e.target.closest('td[data-k]'); if (!td) return;
    rows[+td.parentElement.dataset.i][td.dataset.k] = td.textContent.trim();
    if (td.dataset.k === 'chk') total();
  });

  // Up / Down arrows (and Enter) move to the cell above / below in the same column
  $('mt').addEventListener('keydown', (e) => {
    if (e.key !== 'ArrowDown' && e.key !== 'ArrowUp' && e.key !== 'Enter') return;
    const td = e.target.closest('td[data-k]'); if (!td) return;
    e.preventDefault();
    const tr = td.parentElement;
    const nxt = e.key === 'ArrowUp' ? tr.previousElementSibling : tr.nextElementSibling;
    if (!nxt || !nxt.dataset.i) return;
    const t = nxt.children[[...tr.children].indexOf(td)];
    t.focus();
    const rg = document.createRange(); rg.selectNodeContents(t); rg.collapse(false);
    const sel = window.getSelection(); sel.removeAllRanges(); sel.addRange(rg);
  });

  // ---- fit preview, print, excel
  const sheet = $('sheet'), scaler = $('scaler');
  const fit = () => { scaler.style.zoom = 1; scaler.style.zoom = Math.min(1, ($('stage').clientWidth - 40) / sheet.offsetWidth); };
  window.addEventListener('resize', fit);
  window.addEventListener('beforeprint', () => sheet.classList.add('plain'));
  window.addEventListener('afterprint', () => sheet.classList.remove('plain'));
  $('b-print').onclick = () => window.print();

  $('b-xls').onclick = () => {
    const bin = atob($('mlogo').src.split(',')[1]);
    const bytes = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    const blob = window.buildMetalXlsx({ level: $('i-level').value, floor: $('i-floor').value.trim(), rows }, { bytes, ext: 'jpeg' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `Metal_Report_${($('i-order').value.trim() || 'report').replace(/[\\/:*?"<>|]/g, '-')}_${today}.xlsx`;
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 5000);
  };

  // "read from page" badge + scan beam when the form opens
  const reduce = !!(window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches);
  const CHIPS = [['i-brand', 'Brand'], ['i-sname', 'Style name'], ['i-order', 'Order no.']];
  const updateBadge = () => { $('rd').innerHTML = CHIPS.map(([id, l]) => `<span class="chip ${$(id).value.trim() ? 'ok' : ''}"><i></i>${l}</span>`).join(''); };
  $('panel').addEventListener('input', updateBadge);

  build(); setActive(1); fit(); updateBadge();
  const startIntro = () => {
    if (reduce) return;
    const beam = document.createElement('div'); beam.className = 'beam'; sheet.appendChild(beam);
    beam.addEventListener('animationend', () => beam.remove());
  };
  window.runBoot(CHIPS.filter(([id]) => $(id).value.trim()).length, CHIPS.length, startIntro);
})();
