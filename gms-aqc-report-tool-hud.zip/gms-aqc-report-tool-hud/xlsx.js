// Builds the Moisture Check Report as a real .xlsx file (same layout, borders, formulas and logo as the original Excel).
(function (root) {
  const enc = (s) => new TextEncoder().encode(s);
  const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

  // ---------- minimal ZIP writer (stored) ----------
  const CRC = new Uint32Array(256);
  for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; CRC[n] = c >>> 0; }
  const crc32 = (b) => { let c = 0xFFFFFFFF; for (let i = 0; i < b.length; i++) c = CRC[(c ^ b[i]) & 255] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; };
  function zip(files) {
    const u16 = (v) => [v & 255, (v >> 8) & 255];
    const u32 = (v) => [v & 255, (v >> 8) & 255, (v >> 16) & 255, (v >>> 24) & 255];
    const out = [], cd = []; let off = 0;
    for (const f of files) {
      const nm = enc(f.name), crc = crc32(f.data), sz = f.data.length;
      const lh = new Uint8Array([0x50, 0x4b, 3, 4, ...u16(20), ...u16(0), ...u16(0), ...u16(0), ...u16(0x5C21), ...u32(crc), ...u32(sz), ...u32(sz), ...u16(nm.length), ...u16(0)]);
      out.push(lh, nm, f.data);
      cd.push(new Uint8Array([0x50, 0x4b, 1, 2, ...u16(20), ...u16(20), ...u16(0), ...u16(0), ...u16(0), ...u16(0x5C21), ...u32(crc), ...u32(sz), ...u32(sz), ...u16(nm.length), ...u16(0), ...u16(0), ...u16(0), ...u16(0), ...u32(0), ...u32(off)]), nm);
      off += lh.length + nm.length + sz;
    }
    const cdSize = cd.reduce((a, b) => a + b.length, 0);
    const end = new Uint8Array([0x50, 0x4b, 5, 6, ...u16(0), ...u16(0), ...u16(files.length), ...u16(files.length), ...u32(cdSize), ...u32(off), ...u16(0)]);
    return new Blob([...out, ...cd, end], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
  }

  // ---------- style registry ----------
  function Styles() {
    const fonts = ['<font><sz val="11"/><color rgb="FF000000"/><name val="Calibri"/><family val="2"/></font>'];
    const fills = ['<fill><patternFill patternType="none"/></fill>', '<fill><patternFill patternType="gray125"/></fill>'];
    const borders = ['<border><left/><right/><top/><bottom/><diagonal/></border>'];
    const numFmts = [];
    const xfs = ['<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>'];
    const idx = (arr, x) => { let i = arr.indexOf(x); if (i < 0) { arr.push(x); i = arr.length - 1; } return i; };
    const side = (tag, ch) => ch === 'm' ? `<${tag} style="medium"><color rgb="FF000000"/></${tag}>` : ch === 't' ? `<${tag} style="thin"><color rgb="FF000000"/></${tag}>` : `<${tag}/>`;
    return {
      xf(o) {
        const f = idx(fonts, `<font>${o.b ? '<b/>' : ''}<sz val="${o.sz || 11}"/><color rgb="FF000000"/><name val="${o.name || 'Calibri'}"/><family val="2"/></font>`);
        const fl = o.fill ? idx(fills, `<fill><patternFill patternType="solid"><fgColor rgb="FF${o.fill}"/><bgColor indexed="64"/></patternFill></fill>`) : 0;
        const bd = o.bd || '....';
        const b = idx(borders, `<border>${side('left', bd[0])}${side('right', bd[1])}${side('top', bd[2])}${side('bottom', bd[3])}<diagonal/></border>`);
        let nf = 0; if (o.nf) { nf = 164 + idx(numFmts, o.nf); }
        const al = `<alignment${o.h ? ` horizontal="${o.h}"` : ''}${o.v ? ` vertical="${o.v}"` : ''}${o.wrap ? ' wrapText="1"' : ''}/>`;
        return idx(xfs, `<xf numFmtId="${nf}" fontId="${f}" fillId="${fl}" borderId="${b}" xfId="0" applyNumberFormat="1" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1">${al}</xf>`);
      },
      xml() {
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
          + (numFmts.length ? `<numFmts count="${numFmts.length}">${numFmts.map((n, i) => `<numFmt numFmtId="${164 + i}" formatCode="${esc(n)}"/>`).join('')}</numFmts>` : '')
          + `<fonts count="${fonts.length}">${fonts.join('')}</fonts><fills count="${fills.length}">${fills.join('')}</fills><borders count="${borders.length}">${borders.join('')}</borders>`
          + '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
          + `<cellXfs count="${xfs.length}">${xfs.join('')}</cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>`;
      }
    };
  }

  const colName = (c) => String.fromCharCode(64 + c); // 1 -> A (columns A..T only)

  /**
   * m = { order, sname, style, insp, date, comp, min, max, rows:[{po,country,ctn,t,c,b,rem}] (active rows, max 16),
   *       req:[{name,val,pct}] (8 rows) }
   * logo = Uint8Array (png)
   */
  function buildXlsx(m, logo) {
    const S = Styles();
    const cells = {}; // r -> c -> xml
    const merges = [];
    const put = (r, c, xml) => { (cells[r] = cells[r] || {})[c] = xml; };
    const A = (r, c) => colName(c) + r;
    const sv = (r, c, s, text) => put(r, c, `<c r="${A(r, c)}" s="${s}" t="inlineStr"><is><t xml:space="preserve">${esc(text)}</t></is></c>`);
    const nv = (r, c, s, n) => put(r, c, `<c r="${A(r, c)}" s="${s}"><v>${n}</v></c>`);
    const fv = (r, c, s, f, cached) => put(r, c, `<c r="${A(r, c)}" s="${s}"><f>${esc(f)}</f><v>${cached}</v></c>`);
    const fs = (r, c, s, f, cached) => put(r, c, `<c r="${A(r, c)}" s="${s}" t="str"><f>${esc(f)}</f><v>${esc(cached)}</v></c>`);
    const em = (r, c, s) => { if (!(cells[r] && cells[r][c])) put(r, c, `<c r="${A(r, c)}" s="${s}"/>`); };
    const merge = (r1, c1, r2, c2, s) => { merges.push(`${A(r1, c1)}:${A(r2, c2)}`); for (let r = r1; r <= r2; r++) for (let c = c1; c <= c2; c++) em(r, c, s); };

    // border codes (left,right,top,bottom) for the framed area, as in the original
    const frame = (r, c) => {
      if (r >= 9) return 'mmmm';
      const L = c === 1, R = c === 7;
      if (r === 1) return (L ? 'm' : '.') + (R ? 'm' : '.') + 'mm';
      if (r === 2) return (L ? 'm' : '.') + (R ? 'm' : '.') + 'm.';
      if (r <= 7) return (L ? 'm' : '.') + (R ? 'm' : '.') + '..';
      return (L ? 'm' : '.') + (R ? 'm' : '.') + '.' + (c <= 4 ? 'm' : '.');
    };
    // pre-style every cell of the frame
    for (let r = 1; r <= 27; r++) for (let c = 1; c <= 7; c++) em(r, c, S.xf({ sz: 18, bd: frame(r, c), h: 'center', v: 'center' }));

    // ---- header
    sv(1, 1, S.xf({ sz: 48, h: 'center', v: 'center', bd: frame(1, 1) }), 'BESTSELLER ');
    merge(1, 1, 1, 7, S.xf({ sz: 48, h: 'center', v: 'center', bd: frame(1, 2) }));
    cells[1][1] = `<c r="A1" s="${S.xf({ sz: 48, h: 'center', v: 'center', bd: 'mmmm' })}" t="inlineStr"><is><t xml:space="preserve">BESTSELLER </t></is></c>`;
    cells[1][7] = `<c r="G1" s="${S.xf({ sz: 48, h: 'center', v: 'center', bd: '.mmm' })}"/>`;
    sv(2, 2, S.xf({ sz: 18, h: 'center', v: 'bottom', bd: frame(2, 2) }), 'MOISTURE CHECK REPORT');
    merge(2, 2, 2, 5, S.xf({ sz: 18, h: 'center', v: 'bottom', bd: frame(2, 2) }));

    const lt = (sz, bd, v) => S.xf({ sz, h: 'left', v: v || 'bottom', bd });
    sv(4, 5, lt(18, frame(4, 5)), 'Date :  ' + (m.date || ''));
    sv(5, 1, lt(18, frame(5, 1)), 'SUPPLIER NAME:  GMS Composite Knitting Ind.Ltd');
    sv(5, 5, lt(18, frame(5, 5)), 'Time: ');
    sv(6, 1, lt(16, frame(6, 1), 'top'), 'ORDER NO:  ' + (m.order || ''));
    sv(6, 5, lt(16, frame(6, 5)), 'Style Name:  ' + (m.sname || ''));
    sv(7, 1, lt(18, frame(7, 1)), 'Type of Inspection : Intial / In-line / Pre-Final / Final');
    sv(7, 5, lt(16, frame(7, 5), 'center'), 'Style:  ' + (m.style || ''));
    sv(8, 1, lt(16, frame(8, 1), 'top'), 'INSPECTOR NAME:  ' + (m.insp || ''));
    merge(8, 1, 8, 2, lt(16, frame(8, 1), 'top'));
    sv(8, 5, lt(18, frame(8, 5)), 'Weather Condition: Dry / Raining / Humid');

    // ---- table header
    const hd = S.xf({ sz: 18, h: 'center', v: 'center', bd: 'mmmm' });
    sv(9, 1, hd, 'PO NUMBER');
    sv(9, 2, hd, 'COUNTRY'); merge(9, 2, 10, 2, hd);
    sv(9, 3, hd, 'CTN NO'); merge(9, 3, 10, 3, hd);
    sv(9, 4, hd, 'MOISTURE %'); merge(9, 4, 9, 6, hd);
    sv(9, 7, hd, 'REMARKS'); merge(9, 7, 10, 7, hd);
    sv(10, 4, hd, 'TOP'); sv(10, 5, hd, 'CENTER'); sv(10, 6, hd, 'BOTTOM');

    // ---- data rows 11..26
    const dc = S.xf({ sz: 18, h: 'center', v: 'center', bd: 'mmmm' });
    const dw = S.xf({ sz: 18, h: 'center', v: 'center', bd: 'mmmm', wrap: true });
    const useF = Number.isFinite(m.min) && Number.isFinite(m.max);
    const sums = [[], [], []];
    m.rows.slice(0, 16).forEach((r, i) => {
      const row = 11 + i;
      if (r.po) sv(row, 1, dw, r.po);
      if (r.country) sv(row, 2, dc, r.country);
      if (r.ctn !== '' && r.ctn != null) (/^\d+$/.test(String(r.ctn)) ? nv(row, 3, dc, r.ctn) : sv(row, 3, dc, String(r.ctn)));
      ['t', 'c', 'b'].forEach((k, j) => {
        const v = parseFloat(r[k]);
        if (isNaN(v)) return;
        sums[j].push(v);
        if (useF) fv(row, 4 + j, dc, 'RANDBETWEEN($G$31,$G$32)', v); else nv(row, 4 + j, dc, v);
      });
      if (r.rem) sv(row, 7, dc, r.rem);
    });

    // ---- average row 27
    sv(27, 1, dc, 'Average');
    const av = S.xf({ sz: 18, h: 'center', v: 'center', bd: 'mmmm', nf: '0.0' });
    ['D', 'E', 'F'].forEach((L, j) => { if (sums[j].length) fv(27, 4 + j, av, `AVERAGE(${L}11:${L}26)`, sums[j].reduce((a, b) => a + b, 0) / sums[j].length); });

    // ---- footer (outside the frame)
    const reqRows = (m.req || []).slice(0, 24);
    const totRow = 9 + Math.max(reqRows.length, 1); // total row of the requirement table (Q:T)
    const totalReq = reqRows.reduce((a, r) => a + ((parseFloat(r.val) || 0) * (r.pct || 0)) / 100, 0);
    const fb = (sz, extra) => S.xf(Object.assign({ name: 'Arial', sz, b: true }, extra));
    sv(30, 1, fb(16, { h: 'left', v: 'top', wrap: true }), 'Composition: ' + (m.comp || ''));
    merge(30, 1, 30, 5, fb(16, { h: 'left', v: 'top', wrap: true }));
    sv(30, 6, fb(16, { h: 'center', v: 'bottom', bd: '...t' }), 'Available Moisture');
    merge(30, 6, 30, 7, fb(16, { h: 'center', v: 'bottom', bd: '...t' }));
    const bx = fb(16, { h: 'center', v: 'center', bd: 'tttt' });
    sv(31, 6, bx, 'Minimum'); sv(32, 6, bx, 'Maximum');
    if (Number.isFinite(m.min)) nv(31, 7, bx, m.min); else em(31, 7, bx);
    if (Number.isFinite(m.max)) nv(32, 7, bx, m.max); else em(32, 7, bx);
    fs(32, 1, fb(18, { v: 'bottom' }), `"Moisture Requirement: "&ROUND(T${totRow},2)`, 'Moisture Requirement: ' + Number(totalReq.toFixed(2)));

    // ---- requirement table Q8:T(total row) (outside the print area, feeds the formula above)
    const tb = { bd: 'tttt', h: 'center', v: 'center' };
    sv(8, 17, S.xf(Object.assign({ sz: 16, b: true, fill: 'B7DEE8' }, tb)), 'Moisture Requirement');
    merge(8, 17, 8, 18, S.xf(Object.assign({ sz: 16, b: true, fill: 'B7DEE8' }, tb)));
    for (let i = 0; i < Math.max(reqRows.length, 1); i++) {
      const r = 9 + i, q = reqRows[i] || { name: '', val: '', pct: 0 };
      const ys = S.xf(Object.assign({ sz: 12, fill: 'FFFF00' }, tb));
      if (q.name) sv(r, 17, ys, String(q.name)); else em(r, 17, ys);
      if (q.val !== '' && q.val != null && !isNaN(parseFloat(q.val))) nv(r, 18, ys, parseFloat(q.val)); else em(r, 18, ys);
      const ps = S.xf(Object.assign({ name: 'Arial', sz: 11, b: true }, tb));
      if (q.pct) nv(r, 19, ps, q.pct); else em(r, 19, ps);
      fv(r, 20, S.xf(Object.assign({ name: 'Arial', sz: 11, b: true, fill: '00B050' }, tb)), `R${r}*S${r}/100`, ((parseFloat(q.val) || 0) * (q.pct || 0)) / 100);
    }
    const gs = S.xf(Object.assign({ name: 'Arial', sz: 14, b: true, fill: '92D050' }, tb));
    em(totRow, 17, gs); em(totRow, 18, gs);
    fv(totRow, 19, gs, `SUM(S8:S${totRow - 1})`, reqRows.reduce((a, r) => a + (r.pct || 0), 0));
    fv(totRow, 20, gs, `SUM(T8:T${totRow - 1})`, totalReq);

    // ---- sheet xml
    const heights = { 1: 102, 2: 23.25, 3: 23.25, 4: 23.25, 5: 24.75, 6: 24.75, 7: 23.25, 8: 42.75, 9: 24, 10: 24, 11: 37.5, 28: 15.75, 29: 15.75, 30: 21.75, 31: 21.75, 32: 21.75, 33: 21.75, 34: 20.25 };
    for (let r = 12; r <= 27; r++) heights[r] = 33.75;
    let rowsXml = '';
    for (let r = 1; r <= 34; r++) {
      const cs = cells[r] || {};
      const body = Object.keys(cs).map(Number).sort((a, b) => a - b).map((c) => cs[c]).join('');
      rowsXml += `<row r="${r}"${heights[r] ? ` ht="${heights[r]}" customHeight="1"` : ''}>${body}</row>`;
    }
    const cols = [[1, 35.1], [2, 18], [3, 14.7], [4, 18.6], [5, 19], [6, 16.1], [7, 27.8], [17, 30], [18, 12], [19, 9], [20, 9.9]]
      .map(([c, w]) => `<col min="${c}" max="${c}" width="${w}" customWidth="1"/>`).join('');
    const sheet = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
      + '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
      + '<sheetPr><pageSetUpPr fitToPage="1"/></sheetPr><dimension ref="A1:T34"/>'
      + '<sheetViews><sheetView workbookViewId="0" tabSelected="1"/></sheetViews><sheetFormatPr defaultRowHeight="15"/>'
      + `<cols>${cols}</cols><sheetData>${rowsXml}</sheetData>`
      + `<mergeCells count="${merges.length}">${merges.map((x) => `<mergeCell ref="${x}"/>`).join('')}</mergeCells>`
      + '<printOptions horizontalCentered="1"/><pageMargins left="0.25" right="0.25" top="0.5" bottom="0.5" header="0.3" footer="0.3"/>'
      + '<pageSetup paperSize="9" orientation="portrait" fitToWidth="1" fitToHeight="1"/><drawing r:id="rId1"/></worksheet>';

    const X = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>';
    const drawing = X + '<xdr:wsDr xmlns:xdr="http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">'
      + '<xdr:oneCellAnchor><xdr:from><xdr:col>0</xdr:col><xdr:colOff>2062440</xdr:colOff><xdr:row>0</xdr:row><xdr:rowOff>182160</xdr:rowOff></xdr:from><xdr:ext cx="1404720" cy="809640"/>'
      + '<xdr:pic><xdr:nvPicPr><xdr:cNvPr id="2" name="Logo"/><xdr:cNvPicPr/></xdr:nvPicPr><xdr:blipFill><a:blip xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" r:embed="rId1"/><a:stretch><a:fillRect/></a:stretch></xdr:blipFill>'
      + '<xdr:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="1404720" cy="809640"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></xdr:spPr></xdr:pic><xdr:clientData/></xdr:oneCellAnchor></xdr:wsDr>';
    const files = [
      ['[Content_Types].xml', X + '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Default Extension="png" ContentType="image/png"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/><Override PartName="/xl/drawings/drawing1.xml" ContentType="application/vnd.openxmlformats-officedocument.drawing+xml"/></Types>'],
      ['_rels/.rels', X + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>'],
      ['xl/workbook.xml', X + '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><bookViews><workbookView/></bookViews><sheets><sheet name="MOISTURE" sheetId="1" r:id="rId1"/></sheets><definedNames><definedName name="_xlnm.Print_Area" localSheetId="0">MOISTURE!$A$1:$G$34</definedName></definedNames><calcPr calcId="191029"/></workbook>'],
      ['xl/_rels/workbook.xml.rels', X + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>'],
      ['xl/styles.xml', S.xml()],
      ['xl/worksheets/sheet1.xml', sheet],
      ['xl/worksheets/_rels/sheet1.xml.rels', X + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/drawing" Target="../drawings/drawing1.xml"/></Relationships>'],
      ['xl/drawings/drawing1.xml', drawing],
      ['xl/drawings/_rels/drawing1.xml.rels', X + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="../media/image1.png"/></Relationships>']
    ].map(([name, text]) => ({ name, data: enc(text) }));
    files.push({ name: 'xl/media/image1.png', data: logo });
    return zip(files);
  }

  /**
   * Metal detector report. m = { level, floor, total, rows:[{date,time,cal,buyer,style,order,chk,fail,sign}] (22 rows) }
   * logo = { bytes: Uint8Array, ext: 'jpeg' }
   */
  function buildMetalXlsx(m, logo) {
    const S = Styles();
    const cells = {}; const merges = [];
    const put = (r, c, xml) => { (cells[r] = cells[r] || {})[c] = xml; };
    const A = (r, c) => colName(c) + r;
    const sv = (r, c, s, t) => put(r, c, `<c r="${A(r, c)}" s="${s}" t="inlineStr"><is><t xml:space="preserve">${esc(t)}</t></is></c>`);
    const nv = (r, c, s, n) => put(r, c, `<c r="${A(r, c)}" s="${s}"><v>${n}</v></c>`);
    const fv = (r, c, s, f, v) => put(r, c, `<c r="${A(r, c)}" s="${s}"><f>${esc(f)}</f><v>${v}</v></c>`);
    const em = (r, c, s) => { if (!(cells[r] && cells[r][c])) put(r, c, `<c r="${A(r, c)}" s="${s}"/>`); };
    const merge = (r1, c1, r2, c2, s) => { merges.push(`${A(r1, c1)}:${A(r2, c2)}`); for (let r = r1; r <= r2; r++) for (let c = c1; c <= c2; c++) if (!(r === r1 && c === c1)) em(r, c, s); };
    const cc = { h: 'center', v: 'center', bd: 'tttt' };

    // title block
    sv(2, 5, S.xf({ sz: 20, b: true }), 'GMS COMPOSITE KNITTING .IND .LTD');
    sv(3, 5, S.xf({ sz: 16, b: true, h: 'left', v: 'center' }), '          SARDAGONJ,KASHIMPUR,GAZIPUR');
    sv(4, 5, S.xf({ sz: 11, b: true, h: 'left', v: 'top' }), '                                       METAL DETECTOR REPORT');
    const notes = ['(*)Total quantity of easy body and children orders should pass tha needle detector machine.',
      '(*)If any sample fails ,find tha metal detector part keep it in a sepaeate report.',
      '(*)If metal part is not found , put failling garments a side and mark sure it is destroyed.',
      '(*)Each garments should pass the needle detector one as final check just before packing.',
      '(*)Make sure garments dones not return back into productiuon unit after needle detection is made.',
      '(*)Metal detector machine should be calibrated at least 3 times a day.'];
    notes.forEach((t, i) => sv(5 + i, 1, S.xf({ sz: 11 }), t));
    const lv = S.xf({ sz: 14, h: 'center' });
    sv(10, 6, lv, 'Level :  ' + (m.level || '1.00MM') + ' '); merge(10, 6, 10, 7, lv);
    sv(10, 8, S.xf({ sz: 14 }), 'Floor : ' + (m.floor || ''));

    // header row 12
    const H = (sz, name, extra) => S.xf(Object.assign({ sz, name: name || 'Calibri' }, cc, extra));
    [['DATE', 14], ['TIME', 14], ['CALIBRATED', 11], ['BUYER', 14], ['STYLE NAME', 14], ['ORDER NO', 11, 'Arial'], ['NO OF GARMENTS CHECKED', 11, null, { v: 'top', wrap: true }], ['NO OF GMT FAILING', 11, null, { wrap: true }], ['SIGN', 14]]
      .forEach((x, i) => sv(12, 1 + i, H(x[1], x[2], x[3]), x[0]));

    // data rows 13..34
    const dA = S.xf(Object.assign({ sz: 11, name: 'Arial' }, cc));
    const dC = S.xf(Object.assign({ sz: 11 }, cc));
    const total = [];
    (m.rows || []).slice(0, 22).forEach((r, i) => {
      const row = 13 + i;
      for (let c = 1; c <= 9; c++) em(row, c, (c === 2 || c === 9) ? dC : dA);
      const t = (c, v) => { if (v !== '' && v != null) sv(row, c, (c === 2 || c === 9) ? dC : dA, String(v)); };
      t(1, r.date); t(2, r.time); t(3, r.cal); t(4, r.buyer); t(5, r.style); t(6, r.order);
      const n = parseFloat(r.chk);
      if (!isNaN(n)) { nv(row, 7, dA, n); total.push(n); }
      t(8, r.fail); t(9, r.sign);
    });
    for (let row = 13; row <= 34; row++) for (let c = 1; c <= 9; c++) em(row, c, (c === 2 || c === 9) ? dC : dA);

    // total row 35
    const t35 = S.xf(cc);
    em(35, 1, t35); merge(35, 1, 35, 5, t35);
    sv(35, 6, S.xf(Object.assign({ sz: 12, b: true }, cc)), 'TOTAL');
    fv(35, 7, dA, 'SUM(G13:G34)', total.reduce((a, b) => a + b, 0));
    em(35, 8, t35); em(35, 9, t35);

    // signatures row 39
    const sg = (extra) => S.xf(Object.assign({ sz: 12, b: true, bd: '..t.' }, extra));
    sv(39, 2, sg({ h: 'center', v: 'center' }), 'PREPARED BY');
    sv(39, 5, sg({ h: 'center', v: 'center' }), 'FINISHING MANAGER');
    sv(39, 8, sg({ h: 'left', v: 'top' }), '           APPROVED BY'); merge(39, 8, 39, 9, sg({ h: 'left', v: 'top' }));

    const hts = { 2: 20.25, 3: 20.25, 4: 18.75, 5: 18.75, 6: 16.5, 7: 17.25, 8: 17.25, 9: 16.5, 10: 16.5, 11: 11.25, 12: 31.5, 38: 20.25, 39: 20.25, 40: 20.25 };
    for (let r = 13; r <= 36; r++) hts[r] = 20.25;
    let rowsXml = '';
    for (let r = 1; r <= 40; r++) {
      const cs = cells[r] || {};
      const body = Object.keys(cs).map(Number).sort((a, b) => a - b).map((c) => cs[c]).join('');
      rowsXml += `<row r="${r}"${hts[r] ? ` ht="${hts[r]}" customHeight="1"` : ''}>${body}</row>`;
    }
    const cols = [15.57, 19, 12.57, 22.29, 62.86, 19, 15, 15.14, 16.57].map((w, i) => `<col min="${i + 1}" max="${i + 1}" width="${w}" customWidth="1"/>`).join('');
    const sheet = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
      + '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
      + '<sheetPr><pageSetUpPr fitToPage="1"/></sheetPr><dimension ref="A1:I40"/>'
      + '<sheetViews><sheetView workbookViewId="0" tabSelected="1"/></sheetViews><sheetFormatPr defaultRowHeight="15"/>'
      + `<cols>${cols}</cols><sheetData>${rowsXml}</sheetData>`
      + `<mergeCells count="${merges.length}">${merges.map((x) => `<mergeCell ref="${x}"/>`).join('')}</mergeCells>`
      + '<pageMargins left="0.25" right="0.25" top="0.25" bottom="0.5" header="0.3" footer="0.3"/>'
      + '<pageSetup paperSize="9" orientation="landscape" fitToWidth="1" fitToHeight="1"/><drawing r:id="rId1"/></worksheet>';
    const X = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>';
    const drawing = X + '<xdr:wsDr xmlns:xdr="http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">'
      + '<xdr:oneCellAnchor><xdr:from><xdr:col>0</xdr:col><xdr:colOff>619125</xdr:colOff><xdr:row>0</xdr:row><xdr:rowOff>57150</xdr:rowOff></xdr:from><xdr:ext cx="2047875" cy="819150"/>'
      + '<xdr:pic><xdr:nvPicPr><xdr:cNvPr id="2" name="Logo"/><xdr:cNvPicPr/></xdr:nvPicPr><xdr:blipFill><a:blip xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" r:embed="rId1"/><a:stretch><a:fillRect/></a:stretch></xdr:blipFill>'
      + '<xdr:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="2047875" cy="819150"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></xdr:spPr></xdr:pic><xdr:clientData/></xdr:oneCellAnchor></xdr:wsDr>';
    const ext = logo.ext || 'jpeg';
    const files = [
      ['[Content_Types].xml', X + `<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Default Extension="${ext}" ContentType="image/${ext}"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/><Override PartName="/xl/drawings/drawing1.xml" ContentType="application/vnd.openxmlformats-officedocument.drawing+xml"/></Types>`],
      ['_rels/.rels', X + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>'],
      ['xl/workbook.xml', X + '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><bookViews><workbookView/></bookViews><sheets><sheet name="Metal Report" sheetId="1" r:id="rId1"/></sheets><definedNames><definedName name="_xlnm.Print_Area" localSheetId="0">\'Metal Report\'!$A$1:$I$40</definedName></definedNames><calcPr calcId="191029"/></workbook>'],
      ['xl/_rels/workbook.xml.rels', X + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>'],
      ['xl/styles.xml', S.xml()],
      ['xl/worksheets/sheet1.xml', sheet],
      ['xl/worksheets/_rels/sheet1.xml.rels', X + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/drawing" Target="../drawings/drawing1.xml"/></Relationships>'],
      ['xl/drawings/drawing1.xml', drawing],
      ['xl/drawings/_rels/drawing1.xml.rels', X + `<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="../media/image1.${ext}"/></Relationships>`]
    ].map(([name, text]) => ({ name, data: enc(text) }));
    files.push({ name: `xl/media/image1.${ext}`, data: logo.bytes });
    return zip(files);
  }

  root.buildXlsx = buildXlsx;
  root.buildMetalXlsx = buildMetalXlsx;
  if (typeof module !== 'undefined') module.exports = { buildXlsx, buildMetalXlsx };
})(typeof window !== 'undefined' ? window : globalThis);
