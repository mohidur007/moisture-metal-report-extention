// ---- Runs inside the Qarma page (all frames). Must be self-contained. ----
function extractor() {
  const text = document.body ? document.body.innerText : '';
  const grab = (re) => { const m = text.match(re); return m ? m[1].trim() : ''; };
  const LABEL = /^(order\s*no|order\s*number|item\s*no|item\s*number|item\s*name|order\s*qty|sample\s*qty|inspector|supplier|inspection|location|duration|quality|packing|checklist|sampling|production)/i;
  const PO_RE = /\bGMS[A-Z]{0,4}\d{6,8}\b/;
  const tokens = text.split(/[\t\n]+/).map((s) => s.trim()).filter(Boolean);
  const pos = Array.from(new Set(text.match(/\bGMS[A-Z]{0,4}\d{6,8}\b/g) || []));

  let orderNo = grab(/Order\s*No\.?[\s:]+([A-Za-z0-9+\-]+)/i);
  if (!PO_RE.test(orderNo)) orderNo = '';
  let itemNo = grab(/Item\s*no\.?[\s:]+(\d{6,9})\b/i);
  let itemName = grab(/Item\s*name[\s:]+([^\n\t]+)/i);
  if (!itemName || LABEL.test(itemName)) itemName = '';

  // Table layout (combined inspection / several orders): header cells, then one row per order
  const items = [];
  const h = tokens.findIndex((t, i) => /^order\s*(no\.?|number)$/i.test(t) && tokens.slice(i, i + 8).some((x) => /^item\s*name$/i.test(x)));
  if (h >= 0) {
    for (let i = h + 1; i < tokens.length; i++) {
      const pm = tokens[i].length < 30 && tokens[i].match(/(GMS[A-Z]{0,4}\d{6,8})$/);
      if (!pm) continue;
      for (let k = i + 1; k <= i + 4 && k < tokens.length; k++) {
        if (/^\d{6,9}$/.test(tokens[k])) {
          const nm = tokens[k + 1];
          if (!items.some((x) => x.po === pm[1])) items.push({ po: pm[1], itemNo: tokens[k], itemName: nm && !/^[\d\s\/.,]+$/.test(nm) && !LABEL.test(nm) ? nm : '' });
          break;
        }
      }
    }
  }
  if (!items.length && (itemNo || itemName)) items.push({ po: orderNo, itemNo, itemName });
  if (items.length) {
    const uniq = (a) => Array.from(new Set(a.filter(Boolean)));
    if (!itemNo) itemNo = uniq(items.map((x) => x.itemNo)).join(' / ');
    if (!itemName) itemName = uniq(items.map((x) => x.itemName)).join(' / ');
  }
  // Page title: "10323756 · STYLE NAME"
  if (!itemNo || !itemName) {
    const m = text.match(/^\s*(\d{6,9})\s*[·•]\s*([^\n]+)/m);
    if (m) { if (!itemNo) itemNo = m[1]; if (!itemName) itemName = m[2].trim(); }
  }

  let composition = grab(/Composition\s*:\s*([^\n]+)/i);
  if (!composition) {
    const m = text.match(/(\d{1,3}\s*%\s*[A-Za-z][A-Za-z \-]*(?:,\s*\d{1,3}\s*%\s*[A-Za-z][A-Za-z \-]*)*)/);
    if (m) composition = m[1].trim();
  }

  let inspector = grab(/^Inspector(?![’'s])[ \t:]*\n?[ \t]*([^\n\t]+)/im);
  if (inspector.includes(' - ')) inspector = inspector.split(' - ').pop().trim();

  // Brand (shown as BUYER on the metal report)
  let brand = grab(/\bBrand(?:\s*name)?\s*[:\t]\s*([^\n\t]+)/i);
  if (!brand || LABEL.test(brand)) {
    brand = '';
    const bi = tokens.findIndex((t) => /^brand(\s*name)?$/i.test(t));
    if (bi >= 0 && tokens[bi + 1] && !LABEL.test(tokens[bi + 1]) && tokens[bi + 1].length < 40) brand = tokens[bi + 1];
  }

  return { orderNo, itemNo, itemName, composition, inspector, pos, brand, items };
}

// ---- Shows the form as a modal on the page. Refreshing the tab removes it. ----
function showOverlay(url) {
  const old = document.getElementById('mr-overlay');
  if (old) old.remove();
  const reduce = !!(window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches);
  const cham = (n) => `polygon(${n}px 0,100% 0,100% calc(100% - ${n}px),calc(100% - ${n}px) 100%,0 100%,0 ${n}px)`;
  const wrap = document.createElement('div');
  wrap.id = 'mr-overlay';
  wrap.style.cssText = 'position:fixed;inset:0;z-index:2147483647;display:flex;align-items:center;justify-content:center;background:rgba(2,8,24,.55);backdrop-filter:blur(7px);-webkit-backdrop-filter:blur(7px);';
  const box = document.createElement('div');
  box.style.cssText = `position:relative;width:min(1240px,96vw);height:min(94vh,900px);padding:2px;background:linear-gradient(135deg,#22e6ff,#1d4ed8 55%,#ff2bd6);clip-path:${cham(26)};filter:drop-shadow(0 0 18px rgba(34,230,255,.55));`;
  const frame = document.createElement('iframe');
  frame.src = url;
  frame.style.cssText = `width:100%;height:100%;border:0;display:block;background:#040a1c;clip-path:${cham(25)};`;
  const close = document.createElement('button');
  close.textContent = '✕';
  close.title = 'Close';
  close.style.cssText = 'position:absolute;top:12px;right:30px;z-index:2;width:32px;height:32px;border:1px solid #22e6ff;border-radius:0;background:rgba(4,10,28,.85);color:#22e6ff;font:14px Arial;cursor:pointer;box-shadow:0 0 10px rgba(34,230,255,.6);transition:.15s;';
  close.onmouseenter = () => { close.style.background = '#22e6ff'; close.style.color = '#04102a'; };
  close.onmouseleave = () => { close.style.background = 'rgba(4,10,28,.85)'; close.style.color = '#22e6ff'; };
  close.onclick = () => {
    if (reduce) { wrap.remove(); return; }
    box.animate([{ opacity: 1, transform: 'scale(1)' }, { opacity: 0, transform: 'scale(.96)' }], { duration: 200, fill: 'forwards' });
    wrap.animate([{ opacity: 1 }, { opacity: 0 }], { duration: 220, fill: 'forwards' }).onfinish = () => wrap.remove();
  };
  box.append(frame, close);
  wrap.append(box);
  document.documentElement.appendChild(wrap);
  if (!reduce) {
    wrap.animate([{ opacity: 0 }, { opacity: 1 }], { duration: 260, easing: 'ease-out' });
    box.animate([{ opacity: 0, transform: 'scale(.9)', filter: 'drop-shadow(0 0 40px #22e6ff) brightness(2.2)' }, { opacity: 1, transform: 'scale(1)', filter: 'drop-shadow(0 0 18px rgba(34,230,255,.55)) brightness(1)' }], { duration: 480, easing: 'cubic-bezier(.2,.9,.2,1)' });
  }
}

const msg = (s) => (document.getElementById('msg').textContent = s);

async function openForm(page) {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const res = await chrome.scripting.executeScript({ target: { tabId: tab.id, allFrames: true }, func: extractor });
    const data = { orderNo: '', itemNo: '', itemName: '', composition: '', inspector: '', brand: '', pos: [], items: [] };
    for (const r of res) {
      const v = r.result || {};
      for (const k of ['orderNo', 'itemNo', 'itemName', 'composition', 'inspector', 'brand']) if (!data[k] && v[k]) data[k] = v[k];
      for (const p of v.pos || []) if (!data.pos.includes(p)) data.pos.push(p);
      for (const it of v.items || []) if (!data.items.some((x) => x.po === it.po)) data.items.push(it);
    }
    await chrome.storage.local.set({ pageData: data });
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: showOverlay, args: [chrome.runtime.getURL(page)] });
    window.close();
  } catch (e) {
    msg('Cannot open on this page. Open the Qarma inspection page first.');
  }
}
document.getElementById('moisture').onclick = () => openForm('report.html');
document.getElementById('metal').onclick = () => openForm('metal.html');
