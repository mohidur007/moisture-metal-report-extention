(async function () {
  const $ = (id) => document.getElementById(id);
  const store = await chrome.storage.local.get(['pageData', 'settings']);
  const pd = store.pageData || {};
  const st = store.settings || {};
  const MAXR = 16;

  const DEF_REQ = [['COTTON', 61], ['POLYESTER', 39], ['VISCOSE', 45], ['MODAL', 45], ['ELASTANE', 0], ['NYLON', 65], ['RAYON', 45], ['Polyacrylonitrile (acrylic)', 40], ['Spandex', 0], ['Polymide', 65], ['TENCEL™ Lyocell', 45], ['', '']];
  const ALIAS = { elastane: ['lycra', 'elasthane', 'ea'], nylon: ['polyamide'], 'polyacrylonitrile (acrylic)': ['acrylic', 'polyacrylonitrile'], polymide: ['polyamide', 'polymid'], 'tencel™ lyocell': ['tencel', 'lyocell'] };
  // the table always starts from the defaults: added items and edited values are for this report only and are never saved
  let req = DEF_REQ.map((r) => r.slice());
  chrome.storage.local.remove('settings'); // clear any table saved by older versions
  let pos = Array.from(new Set([pd.orderNo, ...(pd.pos || [])].filter(Boolean)));
  const rows = Array.from({ length: MAXR }, () => ({ po: '', country: '', ctn: '', t: '', c: '', b: '', rem: '' }));
  let active = 10;

  // nothing is saved between reports: everything resets when the page is refreshed
  const pad = (n) => String(n).padStart(2, '0');
  const d = new Date();

  // ---- small animations (shuffle, count-up, scan beam). Skipped when printing or when the system asks for reduced motion.
  const reduce = !!(window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches);
  let instant = false, rollTok = 0;
  const counters = new WeakMap();
  function countTo(el, target, fmt, dur) {
    const tok = {}; counters.set(el, tok);
    if (isNaN(target)) { el.textContent = ''; return; }
    if (instant || reduce) { el.textContent = fmt(target); return; }
    const from = 0, t0 = performance.now(), total = dur || 700;
    const step = (now) => {
      if (counters.get(el) !== tok) return;
      const p = Math.min(1, (now - t0) / total), e = 1 - Math.pow(1 - p, 3);
      el.textContent = p < 1 ? fmt(from + (target - from) * e) : fmt(target);
      if (p < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  }

  // ---- initial values (from the page)
  $('f-date').textContent = `${pad(d.getDate())}.${pad(d.getMonth() + 1)}.${d.getFullYear()}`;
  $('i-pos').value = pos.join(', ');
  $('i-sname').value = pd.itemName || '';
  $('i-style').value = pd.itemNo || '';
  $('i-insp').value = pd.inspector || '';
  $('i-comp').value = pd.composition || '';

  // ---- header fields
  // first PO in full, then "+" and the last two digits of every other PO: GMS4751808+95
  function orderText() {
    if (!pos.length) return pd.orderNo || '';
    return pos[0] + pos.slice(1).map((p) => '+' + p.slice(-2)).join('');
  }
  function syncHeader() {
    $('f-order').textContent = orderText();
    $('f-sname').textContent = $('i-sname').value;
    $('f-style').textContent = $('i-style').value;
    $('f-insp').textContent = $('i-insp').value;
    $('p-sub').textContent = [$('i-style').value, $('i-sname').value].filter(Boolean).join(' · ') || 'Fill the details, then print or save as PDF';
  }

  // ---- requirement table
  function buildReqTable() {
    const box = $('reqtable'); box.innerHTML = '';
    req.forEach((r, i) => {
      const n = document.createElement('input'); n.value = r[0]; n.placeholder = 'fibre';
      const v = document.createElement('input'); v.value = r[1]; v.type = 'number';
      n.oninput = () => { req[i][0] = n.value; updateReq(); };
      v.oninput = () => { req[i][1] = v.value; updateReq(); };
      box.append(n, v);
    });
  }
  $('b-addreq').onclick = () => { req.push(['', '']); buildReqTable(); };

  function parseComp(s) {
    return (s || '').split(/[,;]/).map((x) => x.trim()).filter(Boolean).map((p) => {
      let m = p.match(/(\d+(?:\.\d+)?)\s*%\s*(.*)/);
      if (m) return { pct: +m[1], name: m[2] };
      m = p.match(/(.*?)\s*(\d+(?:\.\d+)?)\s*%/);
      if (m) return { pct: +m[2], name: m[1] };
      return null;
    }).filter(Boolean);
  }
  const esc = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  function reqIndex(name) {
    const n = name.toLowerCase();
    for (let i = 0; i < req.length; i++) {
      const fn = req[i][0];
      if (!fn) continue;
      const keys = [fn.toLowerCase(), ...(ALIAS[fn.toLowerCase()] || [])];
      if (keys.some((k) => new RegExp('\\b' + esc(k) + '\\b').test(n))) return i;
    }
    return -1;
  }
  function findReq(name) { const i = reqIndex(name); return i < 0 ? null : +req[i][1] || 0; }
  function updateReq() {
    const comp = $('i-comp').value.trim();
    $('f-comp').textContent = comp;
    const parts = parseComp(comp);
    let total = 0, sum = 0; const unknown = [];
    parts.forEach((p) => {
      sum += p.pct;
      const r = findReq(p.name);
      if (r === null) unknown.push(p.name); else total += (p.pct * r) / 100;
    });
    const txt = parts.length ? String(Number(total.toFixed(2))) : '';
    const rf = (v) => String(Number(v.toFixed(2)));
    if (txt) { countTo($('f-req'), parseFloat(txt), rf); countTo($('p-req'), parseFloat(txt), rf); }
    else { $('f-req').textContent = ''; $('p-req').textContent = '–'; }
    const warn = [];
    if (parts.length && Math.abs(sum - 100) > 0.01) warn.push(`Composition adds up to ${sum}%, not 100%.`);
    if (unknown.length) warn.push(`No requirement value for: ${unknown.join(', ')}.`);
    $('reqinfo').textContent = warn.join(' ');
  }

  // ---- table
  const num = (v) => parseInt(v);
  function layout() {
    const country = $('i-country').value.trim();
    const ctns = $('i-ctn').value.split(/[,\s]+/).filter(Boolean);
    rows.forEach((r, i) => {
      if (i < active) {
        if (!r.po || !pos.includes(r.po)) r.po = i > 0 ? rows[i - 1].po : pos[0] || '';
        if (country) r.country = country;
        if (ctns.length) r.ctn = ctns[i % ctns.length];
      } else {
        r.po = r.country = r.ctn = r.t = r.c = r.b = r.rem = '';
      }
    });
  }
  function randomize(onlyEmpty) {
    const mn = num($('i-min').value), mx = num($('i-max').value);
    if (isNaN(mn) || isNaN(mx)) return;
    const lo = Math.min(mn, mx), hi = Math.max(mn, mx);
    const rnd = () => String(lo + Math.floor(Math.random() * (hi - lo + 1)));
    rows.forEach((r, i) => {
      if (i >= active) return;
      ['t', 'c', 'b'].forEach((k) => { if (!onlyEmpty || !r[k]) r[k] = rnd(); });
    });
  }
  function ptxt(i) { const r = rows[i]; return !r.po ? '' : i > 0 && rows[i - 1].po === r.po ? '"' : r.po; }
  function refreshPO() {
    document.querySelectorAll('#tbody tr').forEach((tr, i) => {
      const sel = tr.querySelector('select'); sel.innerHTML = '';
      const list = ['', ...pos]; if (rows[i].po && !pos.includes(rows[i].po)) list.push(rows[i].po);
      list.forEach((p) => { const o = document.createElement('option'); o.value = p; o.textContent = p; sel.appendChild(o); });
      sel.value = rows[i].po;
      tr.querySelector('.ptxt').textContent = ptxt(i);
    });
  }
  function render() {
    rollTok++;
    const tb = $('tbody'); tb.innerHTML = '';
    rows.forEach((r, i) => {
      const tr = document.createElement('tr'); tr.dataset.i = i;
      const tdPo = document.createElement('td'); tdPo.className = 'po';
      const sel = document.createElement('select');
      sel.onchange = () => { for (let j = i; j < active; j++) rows[j].po = sel.value; if (i >= active) rows[i].po = sel.value; refreshPO(); };
      const sp = document.createElement('span'); sp.className = 'ptxt';
      tdPo.append(sel, sp); tr.appendChild(tdPo);
      ['country', 'ctn', 't', 'c', 'b', 'rem'].forEach((k) => {
        const td = document.createElement('td');
        td.className = 'ed'; td.contentEditable = 'true'; td.dataset.k = k; td.textContent = r[k];
        tr.appendChild(td);
      });
      tb.appendChild(tr);
    });
    refreshPO(); avg();
  }
  $('tbody').addEventListener('input', (e) => {
    const td = e.target.closest('td[data-k]'); if (!td) return;
    if (td.dataset.k === 'country') {
      const f = fmtCountry(td.textContent);
      if (f !== td.textContent) {
        td.textContent = f;
        const rg = document.createRange(); rg.selectNodeContents(td); rg.collapse(false);
        const sel = window.getSelection(); sel.removeAllRanges(); sel.addRange(rg);
      }
    }
    rows[+td.parentElement.dataset.i][td.dataset.k] = td.textContent.trim();
    if ('tcb'.includes(td.dataset.k)) avg();
  });
  // Up / Down arrows (and Enter) move to the cell above / below in the same column, so country and carton numbers can be typed quickly
  $('tbody').addEventListener('keydown', (e) => {
    if (e.key !== 'ArrowDown' && e.key !== 'ArrowUp' && e.key !== 'Enter') return;
    const td = e.target.closest('td[data-k]'); if (!td) return;
    e.preventDefault();
    const tr = td.parentElement;
    const nxt = e.key === 'ArrowUp' ? tr.previousElementSibling : tr.nextElementSibling;
    if (!nxt) return;
    const t = nxt.children[[...tr.children].indexOf(td)];
    t.focus();
    const rg = document.createRange(); rg.selectNodeContents(t); rg.collapse(false);
    const sel = window.getSelection(); sel.removeAllRanges(); sel.addRange(rg);
  });
  function avg(anim) {
    ['t', 'c', 'b'].forEach((k) => {
      const v = rows.map((r) => parseFloat(r[k])).filter((x) => !isNaN(x));
      const el = $('a-' + k);
      if (!v.length) { el.textContent = ''; return; }
      const val = v.reduce((a, b) => a + b, 0) / v.length;
      if (anim) countTo(el, val, (x) => x.toFixed(1), 650); else { counters.set(el, {}); el.textContent = val.toFixed(1); }
    });
  }
  // random numbers "roll" in the new cells row by row, then settle; averages count up afterwards
  function roll(before) {
    const tok = ++rollTok;
    if (reduce) return;
    const mn = num($('i-min').value), mx = num($('i-max').value);
    if (isNaN(mn) || isNaN(mx)) return;
    const lo = Math.min(mn, mx), hi = Math.max(mn, mx);
    const cells = [];
    document.querySelectorAll('#tbody tr').forEach((tr, i) => {
      if (i >= active) return;
      ['t', 'c', 'b'].forEach((k) => {
        if (before && before[i] && before[i][k] === rows[i][k]) return;
        const td = tr.querySelector(`td[data-k="${k}"]`);
        td.classList.add('rolling');
        cells.push({ td, final: rows[i][k], end: 350 + i * 70 + Math.random() * 120 });
      });
    });
    if (!cells.length) return;
    ['t', 'c', 'b'].forEach((k) => { counters.set($('a-' + k), {}); $('a-' + k).textContent = ''; });
    const t0 = performance.now();
    const timer = setInterval(() => {
      if (tok !== rollTok) { clearInterval(timer); return; }
      const el = performance.now() - t0; let left = 0;
      cells.forEach((c) => {
        if (c.done) return;
        if (el >= c.end) { c.td.textContent = c.final; c.td.classList.remove('rolling'); c.done = true; }
        else { left++; c.td.textContent = String(lo + Math.floor(Math.random() * (hi - lo + 1))); }
      });
      if (!left) { clearInterval(timer); avg(true); }
    }, 50);
  }
  // show final values at once (used before printing)
  function settle() { instant = true; render(); updateReq(); instant = false; }
  function minmax() { $('f-min').textContent = $('i-min').value; $('f-max').textContent = $('i-max').value; }

  // ---- live events: everything fills as soon as you type
  const refill = (regen) => {
    const before = rows.map((r) => ({ t: r.t, c: r.c, b: r.b }));
    layout(); if (regen) randomize(false); render();
    if (regen) roll(before);
  };
  const fmtCountry = (t) => { const v = String(t).replace(/^[#\s]+/, ''); return v ? '# ' + v : ''; };
  $('i-country').oninput = () => {
    const f = fmtCountry($('i-country').value);
    if (f !== $('i-country').value) $('i-country').value = f;
    rows.forEach((r, i) => { if (i < active) r.country = f; }); // an empty box clears the column again
    render();
  };
  $('i-ctn').oninput = () => {
    const ctns = $('i-ctn').value.split(/[,\s]+/).filter(Boolean);
    rows.forEach((r, i) => { if (i < active) r.ctn = ctns.length ? ctns[i % ctns.length] : ''; });
    render();
  };
  ['i-min', 'i-max'].forEach((id) => ($(id).oninput = () => { minmax(); refill(true); }));
  $('i-rows').oninput = () => {
    const n = num($('i-rows').value);
    if (isNaN(n)) return;
    active = Math.min(MAXR, Math.max(1, n));
    const before = rows.map((r) => ({ t: r.t, c: r.c, b: r.b }));
    layout(); randomize(true); render(); roll(before);
  };
  $('b-fill').onclick = () => {
    if (isNaN(num($('i-min').value)) || isNaN(num($('i-max').value))) { $('i-min').focus(); return; }
    refill(true);
  };
  $('i-pos').oninput = () => {
    pos = $('i-pos').value.split(/[,\s]+/).filter(Boolean);
    rows.forEach((r, i) => { if (i < active && !pos.includes(r.po)) r.po = pos[0] || ''; });
    syncHeader(); refill(false);
  };
  ['i-sname', 'i-style', 'i-insp'].forEach((id) => ($(id).oninput = syncHeader));
  $('i-comp').oninput = () => { updateReq(); syncCompWarn(); };

  // ---- fit the A4 preview to the available width
  const sheet = $('sheet'), scaler = $('scaler');
  function fit() {
    scaler.style.zoom = 1;
    const z = Math.min(1, ($('stage').clientWidth - 40) / sheet.offsetWidth);
    scaler.style.zoom = z;
  }
  window.addEventListener('resize', fit);

  // ---- print
  window.addEventListener('beforeprint', () => { sheet.classList.add('plain'); settle(); });
  window.addEventListener('afterprint', () => sheet.classList.remove('plain'));
  $('b-print').onclick = () => window.print();

  // ---- Excel download (same layout, formulas, borders and logo as the original sheet)
  function logoBytes() {
    const bin = atob($('logo-svg').src.split(',')[1]);
    const u = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i);
    return u;
  }
  function downloadExcel() {
    const pct = req.map(() => 0);
    parseComp($('i-comp').value).forEach((p) => { const i = reqIndex(p.name); if (i >= 0) pct[i] += p.pct; });
    const model = {
      order: $('f-order').textContent.trim(), sname: $('f-sname').textContent.trim(), style: $('f-style').textContent.trim(),
      insp: $('f-insp').textContent.trim(), date: $('f-date').textContent.trim(), comp: $('f-comp').textContent.trim(),
      min: parseFloat($('i-min').value), max: parseFloat($('i-max').value),
      rows: rows.map((r, i) => Object.assign({}, r, { po: ptxt(i) })),
      req: req.map((r, i) => ({ name: r[0], val: r[1], pct: pct[i] }))
    };
    const blob = window.buildXlsx(model, logoBytes());
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `Moisture_${(model.style || 'report').replace(/[\\/:*?"<>|]/g, '-')}_${model.date}.xlsx`;
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 5000);
  }
  $('b-xls').onclick = downloadExcel;

  // ---- start
  // "read from page" badge: green when the field has a value, amber when it is empty
  const CHIPS = [['i-pos', 'PO numbers'], ['i-sname', 'Style name'], ['i-style', 'Style no.'], ['i-insp', 'Inspector'], ['i-comp', 'Composition']];
  function updateBadge() {
    $('rd').innerHTML = CHIPS.map(([id, label]) => `<span class="chip ${$(id).value.trim() ? 'ok' : ''}"><i></i>${label}</span>`).join('');
  }
  $('panel').addEventListener('input', updateBadge);

  buildReqTable(); updateReq(); syncHeader(); minmax(); updateBadge(); syncCompWarn();
  layout(); render(); fit();
  // red warning when the composition could not be read from the page
  function syncCompWarn() { $('compwarn').hidden = !!$('i-comp').value.trim(); }
  function showWarn() { $('warn').hidden = false; $('warn-ok').focus(); }
  $('warn-ok').onclick = () => { $('warn').hidden = true; $('i-comp').focus(); };
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && !$('warn').hidden) $('warn').hidden = true; });

  const startIntro = () => {
    if (!$('i-comp').value.trim()) setTimeout(showWarn, reduce ? 0 : 450);
    if (reduce) return;
    sheet.classList.add('intro');
    const beam = document.createElement('div'); beam.className = 'beam'; sheet.appendChild(beam);
    beam.addEventListener('animationend', () => beam.remove());
    setTimeout(() => sheet.classList.remove('intro'), 1700);
  };
  window.runBoot(CHIPS.filter(([id]) => $(id).value.trim()).length, CHIPS.length, startIntro);
})();
